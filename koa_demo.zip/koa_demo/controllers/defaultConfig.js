const config = {
    database:{
        DATABASE:"blog_dev",
        USERNAME:"root",
        PASSWORD:"wm000819",
        PORT:"3306",
        HOST:"localhost"
    }
}
module.exports = config;