const baseUrl = 'http://10.211.55.5:4000/'

export default {
  baseUrl
}
